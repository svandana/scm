# -*- coding: utf-8 -*-
"""
Created on Fri Jan 17 10:41:40 2025

@author: hivan
"""

import tkinter
from tkinter import*
from tkinter import ttk
import pymysql
from tkinter import messagebox

t = tkinter.Tk()
t.geometry('700x700')
t.title('Service Centre Management')


heading=Label(t,text='Add Staff', font=('helvetica',14))
heading.place(x=30,y=30)

def close():
    t.destroy()
    
def clear():
    staffIdEntry.delete(0,100)
    snameEntry.delete(0,100)
    addressEntry.delete(0,100)
    phoneEntry.delete(0,100)
    emailEntry.delete(0,100)
    
    
def addstaff():
    db = pymysql.connect(host='localhost', user='root', password = 'root', database = 'scm')
    cur = db.cursor()
    
    xa = staffIdEntry.get()
    xb = snameEntry.get()
    xc = addressEntry.get()
    xd = phoneEntry.get()
    xe = emailEntry.get()
    
    sql = "insert into staff values('%s','%s','%s','%s','%s')" %(xa,xb,xc,xd,xe) 
    
    cur.execute(sql)
    db.commit()
    
    messagebox.showinfo('Hi','Staff Added')
    
    staffIdEntry.delete(0,100)
    snameEntry.delete(0,100)
    addressEntry.delete(0,100)
    phoneEntry.delete(0,100)
    emailEntry.delete(0,100)
    
    db.close()
  
def check():
    db = pymysql.connect(host='localhost', user='root', password = 'root', database = 'scm')
    cur = db.cursor()
    
    xa = staffIdEntry.get()
    
    sql = "select count(*) from staff where staffid = '%s'" %(xa)
    cur.execute(sql)
    data=cur.fetchone()
    
    if data[0] == 0:
        messagebox.showinfo('Hi','Staff not registered.')
    else:
        messagebox.showinfo('Hi', 'Staff already registered!')
        
    db.close()    
    
  


staffId=Label(t,text='Staff ID : ')
staffId.place(x=30,y=80)
staffIdEntry=Entry(t,width=20)
staffIdEntry.place(x=120,y=80)


check=Button(t,text='Check',command=check)
check.place(x=280,y=80)

sname=Label(t,text='Staff Name : ')
sname.place(x=30,y=110)
snameEntry=Entry(t,width=20)
snameEntry.place(x=120,y=110)

address=Label(t,text='Address : ')
address.place(x=30,y=140)
addressEntry=Entry(t,width=20)
addressEntry.place(x=120,y=140)

phone=Label(t,text='Phone : ')
phone.place(x=30,y=170)
phoneEntry=Entry(t,width=20)
phoneEntry.place(x=120,y=170)

email=Label(t,text='Email : ')
email.place(x=30,y=200)
emailEntry=Entry(t,width=20)
emailEntry.place(x=120,y=200)




save=Button(t,text='Save',command=addstaff)
save.place(x=30,y=260)

clear=Button(t,text='Clear',command=clear)
clear.place(x=90,y=260)

close=Button(t,text='Close', command=close)
close.place(x=145,y=260)




t.mainloop()